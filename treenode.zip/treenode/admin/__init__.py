# -*- coding: utf-8 -*-
from .admin import TreeNodeModelAdmin

__all__ = ["TreeNodeModelAdmin"]
