# -*- coding: utf-8 -*-
"""
The TreeNode Model

Version: 3.0.0
Author: Timur Kady
Email: timurkady@yandex.com
"""
from .models import TreeNodeModel

__all__ = ["TreeNodeModel"]
