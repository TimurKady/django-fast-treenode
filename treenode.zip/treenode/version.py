# -*- coding: utf-8 -*-
"""
TreeNode Version Module

This module defines the current version of the TreeNode package.

Version: 3.0.0
Author: Timur Kady
Email: timurkady@yandex.com
"""


__version__ = '3.0.0'
