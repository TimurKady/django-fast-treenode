Application for supporting tree (hierarchical) data structure in Django projects
Combination of Adjacency List and Closure Table

See details at https://github.com/TimurKady/django-fast-treenode