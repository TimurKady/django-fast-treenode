================================================================================

FAST TREENODE

Application for supporting tree (hierarchical) data structure in Django projects
Combination of Adjacency List and Closure Table

================================================================================


Quick start
-----------

Quick start
1. Run pip install django-treenode
2. Add fast-treenode to settings.INSTALLED_APPS
3. Make your model inherit from treenode.models.TreeNodeModel (see the documentation for an example)
4. Make your model-admin inherit from treenode.admin.TreeNodeModelAdmin (see the documentation for an example)
5. Run python manage.py makemigrations and python manage.py migrate

When updating an existing project, simply call cls.update_tree() function once. 
It will automatically build a new and complete Closure Table for your tree.

